
<?php
$conn = mysql_connect("videotheme.cbwyqwyfbexe.ap-south-1.rds.amazonaws.com", "videotheme", "videotheme");
mysql_select_db('sales_crm', $conn);