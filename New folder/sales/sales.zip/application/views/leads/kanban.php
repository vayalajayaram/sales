<?php include_once(APPPATH . 'views/inc/header.php'); ?>

<div class="ciuis-body-content" ng-controller="Leads_Controller">
	
<script>var MSG_TITLE = '<?php echo lang('attention') ?>',MSG_REMOVE = '<?php echo lang('converted_lead_remove_msg') ?>',MSG_CANCEL = '<?php echo lang('cancel') ?>',MSG_OK = '<?php echo lang('yes') ?>'</script>
<?php include_once( APPPATH . 'views/inc/footer.php' );?>